package com.example.convert_number_to_words;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText Num;
    private TextView tvResult;
    private Button btnCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Num =findViewById(R.id.numb);
        tvResult =findViewById(R.id.txtResult);
        btnCalculate=findViewById(R.id.btnConverter);

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num;
                num=Integer.parseInt(Num.getText().toString());
                Converter converter= new Converter(num);
                tvResult.setText(converter.Check());
            }
        });
    }
}

